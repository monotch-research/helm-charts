#!/usr/bin/env bash
set -euo pipefail

DOCKERHUB_USER="${DOCKERHUB_USER:-}"
DOCKERHUB_TOKEN="${DOCKERHUB_TOKEN:-}"

if [[ -z "$DOCKERHUB_USER" ]]; then
  read -rp "Docker Hub username: " DOCKERHUB_USER
fi

if [[ -z "$DOCKERHUB_TOKEN" ]]; then
  read -rsp "Docker Hub token/password: " DOCKERHUB_TOKEN
  echo
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "Packaging chart..."
helm package "$SCRIPT_DIR"

CHART_NAME=$(helm show chart "$SCRIPT_DIR" | grep '^name:' | awk '{print $2}')
CHART_VERSION=$(helm show chart "$SCRIPT_DIR" | grep '^version:' | awk '{print $2}')
PACKAGE="${CHART_NAME}-${CHART_VERSION}.tgz"

echo "Logging in to Docker Hub..."
echo "$DOCKERHUB_TOKEN" | helm registry login registry-1.docker.io \
  --username "$DOCKERHUB_USER" \
  --password-stdin

echo "Pushing ${PACKAGE} to oci://registry-1.docker.io/${DOCKERHUB_USER}..."
helm push "$PACKAGE" "oci://registry-1.docker.io/${DOCKERHUB_USER}"

echo "Done. Pull with:"
echo "  helm pull oci://registry-1.docker.io/${DOCKERHUB_USER}/${CHART_NAME} --version ${CHART_VERSION}"
